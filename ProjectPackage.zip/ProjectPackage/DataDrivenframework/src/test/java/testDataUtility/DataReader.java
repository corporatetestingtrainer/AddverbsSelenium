package testDataUtility;

import java.util.ArrayList;

import util.Xls_Reader;

public class DataReader {
	
	static Xls_Reader excelreader;
	
	public static ArrayList<Object[]> getExcelData()
	{
		ArrayList<Object[]> testdata_obj = new ArrayList<Object[]>();
		
		excelreader = new Xls_Reader("C:\\Trainings\\Automation\\Addverbs\\AddverbsProjects\\DataDrivenframework\\src\\test\\resources\\Testcasedata.xlsx");
		
		for (int row =2; row <=excelreader.getRowCount("TestData");row++)
		{
			String email = excelreader.getCellData("TestData", "UserName", row);
			String pass = excelreader.getCellData("TestData", "Password", row);
			
			Object obj[] = {email, pass};
			testdata_obj.add(obj);

		}
		return testdata_obj;
	}

}

package testcases;

public class MutualFunds {

}

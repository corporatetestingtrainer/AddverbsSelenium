package testcases;

public class Stocks {

}

package testcases;

public class InvestmentTool {

}

package testcases;

import org.testng.annotations.Test;

import keywords.ApplicationKeyword;

public class ProtfoilioTest {
	
	ApplicationKeyword appKeyword = new ApplicationKeyword();

	@Test
	public void createPortfoilioTest() 
	{
		// Login
		// Create
		// Verify
		
	
		appKeyword.openBrowser("Chrome");
		// opening application
		appKeyword.navigate("ApplicationURL");
		// clicking on the My Money link
		appKeyword.click("MoneyLink_xpath");
		// clicking on the my portfoilio link
		appKeyword.click("myPortfoilio_xpath");
		// Enter the email address in the text field
		appKeyword.type("UserName_id", "corporatetestingtrainer@gmail.com");
		// Enter the password in the password text field
		appKeyword.type("Password_name", "email@gmail.com");
		appKeyword.click("loginSumbit_id");
	
//	appKeyword.validatePageTitle();
//	appKeyword.logout();


	}
	
	@Test
	public void deletePortfoilioTest()
	{
		// login
		// verify the created profile which need to be deleted
		// Delete
		// Verify
		
		appKeyword.openBrowser("Chrome");
		// opening application
		appKeyword.navigate("ApplicationURL");
		// clicking on the My Money link
		appKeyword.click("MoneyLink_xpath");
		// clicking on the my portfoilio link
		appKeyword.click("myPortfoilio_xpath");
		// Enter the email address in the text field
		appKeyword.type("UserName_id", "corporatetestingtrainer@gmail.com");
		// Enter the password in the password text field
		appKeyword.type("Password_name", "email@gmail.com");
		appKeyword.click("loginSumbit_id");
	}
	
	@Test
	public void renamePortfoilioTest()
	{
		// login
		// verify the created profile which need to be deleted
		// Delete
		// Verify
		
		// launch the browser
		appKeyword.openBrowser("Chrome");
		// opening application
		appKeyword.navigate("ApplicationURL");
		// clicking on the My Money link
		appKeyword.click("MoneyLink");
		// clicking on the my portfoilio link
		appKeyword.click("myPortfoilio");
		// Enter the email address in the text field
		appKeyword.type("UserName", "corporatetestingtrainer@gmail.com");
		// Enter the password in the password text field
		appKeyword.type("Password", "email@gmail.com");
		appKeyword.click("loginbutton");
	}
	
	
}

package testcases;

import java.util.ArrayList;
import java.util.Iterator;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import keywords.ApplicationKeyword;
import testDataUtility.DataReader;


public class CreatePortfoilioTest {
	
	
	@DataProvider
	public Iterator<Object[]> getdata()
	{
		ArrayList<Object[]> testdata = DataReader.getExcelData();
		return testdata.iterator();
	}
	
	@Test (dataProvider =  "getdata")
	public void createPortfoilioTest(String username, String Pass) throws InterruptedException
	{
		// Login
		// Create
		// Verify
		
	
	ApplicationKeyword appKeyword = new ApplicationKeyword();
	// launch the browser
	appKeyword.openBrowser("Chrome");
	// opening application
	appKeyword.navigate("ApplicationURL");
	// clicking on the My Money link
	appKeyword.click("MoneyLink_xpath");
	// clicking on the my portfoilio link
	appKeyword.click("myPortfoilio_xpath");
	// Enter the email address in the text field
	Thread.sleep(5);
	appKeyword.type("UserName_id", username);
	// Enter the password in the password text field
	appKeyword.type("Password_name", Pass);
	appKeyword.click("loginSumbit_id");
//	appKeyword.validatePageTitle();
//	appKeyword.logout();

		
		
		
		
		
	}

}

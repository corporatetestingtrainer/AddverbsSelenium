package keywords;

public class Validationkeywords extends Generickeywords{
	
	
	
	public void validateText()
	{
		
	}
	
	public void validatePageTitle()
	{
		
	}
	
	public void validateElementPresence()
	{
		
	}

}

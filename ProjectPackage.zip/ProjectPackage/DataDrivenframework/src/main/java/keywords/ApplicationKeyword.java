package keywords;

import java.io.FileInputStream;
import java.util.Properties;

public class ApplicationKeyword extends Validationkeywords{
	
	
	public ApplicationKeyword()
	{
		String path = System.getProperty("user.dir")+"//src//test//resources/config.properties";
		prop = new Properties();
		
		try
		{
			FileInputStream fs = new FileInputStream(path);
			prop.load(fs);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	public void login()
	{
		
	}
	
	public void logout()
	{
		
	}
	
	public void selectDate()
	{
		
	}

}

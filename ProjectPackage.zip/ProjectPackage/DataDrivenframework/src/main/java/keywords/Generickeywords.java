package keywords;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Generickeywords {
	
	public WebDriver driver;
	public Properties prop;
	
	
	public void openBrowser(String browserName)
	{
		if (browserName.equals("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "C:\\Trainings\\Automation\\Addverbs\\SeleniumDriver\\geckodriver-v0.32.2-win64\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else if (browserName.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Trainings\\Automation\\Addverbs\\SeleniumDriver\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if (browserName.equals("Edge"))
		{
		System.setProperty("webdriver.edge.driver", "C:\\Trainings\\Automation\\Addverbs\\SeleniumDriver\\edgedriver_win64\\msedgedriver.exe");
		driver = new EdgeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		System.out.println(browserName +" - browser is luanched");
	}
	
	public void navigate(String url)
	{
		driver.get(prop.getProperty(url));
		System.out.println("Naviagted to the URL "+url);

	}
	
	public void click (String locatorKey)
	{
//		String loc = prop.getProperty(locator);
//		getElement(loc).click();
		getElement(locatorKey).click();
//		getElement(prop.getProperty(locator)).click();
		System.out.println("Clicking on the button - "+locatorKey);
	}
	
	public void type(String locator, String data)
	{
		getElement(locator).sendKeys(data);
		//getElement(prop.getProperty(locator)).sendKeys(data);
		System.out.println("Typing in - "+locator +" - data - "+data);
	}
	
	public void select(String locator, String data)
	{
		System.out.println("Selecting the dropdown from in - "+locator +" - data - "+data);
	}
	
	public void getText (String locator)
	{
		System.out.println("Getting the text value from in - "+locator);

	}
	
	// central function to exact the element
	public WebElement getElement (String locatorKey)
	{
		// check the presence
		if (!isElementPresent(locatorKey))
		{
			//report failure
			System.out.println("Element not prsent - "+locatorKey);
		}
		
		// check for the visibility
		if (!isElementVisible(locatorKey))
		{
			//report failure
			System.out.println("Element not visible - "+locatorKey);
		}
		
		//WebElement e = driver.findElement(By.xpath(locator));
//		WebElement e = null;
		
//		if (locatorKey.endsWith("_id"))
//		{
//			e=driver.findElement(By.id(prop.getProperty(locatorKey)));
//		}
//		else if (locatorKey.endsWith("_xpath"))
//		{
//			e=driver.findElement(By.xpath(prop.getProperty(locatorKey)));
//		}
//		
//		else if (locatorKey.endsWith("_css"))
//		{
//			e=driver.findElement(By.cssSelector(prop.getProperty(locatorKey)));
//		}
//		else if (locatorKey.endsWith("_name"))
//		{
//			e=driver.findElement(By.name(prop.getProperty(locatorKey)));
//		}
		
		WebElement e = driver.findElement(getlocator(locatorKey));
		
		return e;
	}
	
	// true - present
	// false - not present
	public boolean isElementPresent(String locatorKey)
	{
		System.out.println("checking for the presence of - "+locatorKey);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		try
		{
			if (locatorKey.endsWith("_id"))
			{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(prop.getProperty(locatorKey))));
			}
			else if (locatorKey.endsWith("_xpath"))
			{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(prop.getProperty(locatorKey))));
			}
			
			else if (locatorKey.endsWith("_css"))
			{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(prop.getProperty(locatorKey))));
			}
			else if (locatorKey.endsWith("_name"))
			{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(prop.getProperty(locatorKey))));
			}
		}
		catch (Exception e)
		{
		return false;
		}
		return true;
	}
	
	public boolean isElementVisible(String locatorKey)
	{
		System.out.println("checking for the visible of - "+locatorKey);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		try
		{
			if (locatorKey.endsWith("_id"))
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(prop.getProperty(locatorKey))));

			}
			else if (locatorKey.endsWith("_xpath"))
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty(locatorKey))));
			}
			
			else if (locatorKey.endsWith("_css"))
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(prop.getProperty(locatorKey))));
			}
			else if (locatorKey.endsWith("_name"))
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(prop.getProperty(locatorKey))));
			}
			
		}
		catch (Exception e)
		{
		return false;
		}
		return true;
	}
	
	public By getlocator(String locatorKey)
	{
		By by = null;
		if (locatorKey.endsWith("_id"))
		{
			by=(By.id(prop.getProperty(locatorKey)));
		}
		else if (locatorKey.endsWith("_xpath"))
		{
			by=(By.xpath(prop.getProperty(locatorKey)));
		}
		
		else if (locatorKey.endsWith("_css"))
		{
			by= (By.cssSelector(prop.getProperty(locatorKey)));
		}
		else if (locatorKey.endsWith("_name"))
		{
			by = (By.name(prop.getProperty(locatorKey)));
		}
		return by;
		
	}
	

}

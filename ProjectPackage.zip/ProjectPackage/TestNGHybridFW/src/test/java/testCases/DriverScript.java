package testCases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import datatable.Xls_Reader;

public class DriverScript {
	
	public static Properties CONFIG;
	public static Properties OR;
	public static Properties APPTEXT;
	public static Xls_Reader controller;
	public static Xls_Reader testData;
	
	public static String keyword;
	public static String currentTSID;
	public static String proceedOnFail;
	public static String stepDescription;
	public static WebDriver driver = null;
	public static String object;
	public static String testStatus;
	
	public static int testRepeat;
	public static String data_column_name;
	
	public static String currentTest;
	
	public static Logger APPLICATION_LOGS = Logger.getLogger("devpinoyLogger");
	
	
	@BeforeClass
	public static void startTesting()
	{
		ReportUtil.startTesting("C://Report//index.html", TestUtil.now("dd.MMMM.yyyy hh.mm.ss.aaa"), "PreProd", "1.1.3");
	}
	
	@BeforeTest
	public void initialize () throws IOException
	{
		// load the property files
		// load the config/OR prop
		
		CONFIG = new Properties();
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\config\\config.properties");
		CONFIG.load(fs);
		
		OR = new Properties();
		fs = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\config\\OR.properties");
		OR.load(fs);
		
		APPTEXT = new Properties();
		fs = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\config\\app_text.properties");
		APPTEXT.load(fs);
		
		controller = new Xls_Reader(System.getProperty("user.dir")+"\\src\\main\\java\\config\\Controller.xlsx");
		testData = new Xls_Reader(System.getProperty("user.dir")+"\\src\\main\\java\\config\\TestData.xlsx");
	}
	
	@Test
	public void testApp() {
		String startTime=null;
		ReportUtil.startSuite("Suite 1");
		for(int tcid=2 ; tcid<=controller.getRowCount("Suite1");tcid++){
			currentTest = controller.getCellData("Suite1", "TCID", tcid);
			// initilize start time of test
			if(controller.getCellData("Suite1", "Runmode", tcid).equals("Y")){
				// execute the keywords
				// loop again - rows in test data
				int totalSets=testData.getRowCount(currentTest); // holds total rows in test data sheet. IF sheet does not exist then 2 by default
				System.out.println("number of data -->"+totalSets);
				if(totalSets<=1){
					totalSets=2; // run atleast once
				}
					
				for( testRepeat=2; testRepeat<=totalSets;testRepeat++){	
					startTime=TestUtil.now("dd.MMMMM.yyyy hh.mm.ss aaa");

				// implement keyword . Reflection API
//				System.out.println(controller.getRowCount(currentTest));
				for(int tsid=2;tsid<=controller.getRowCount(currentTest);tsid++){
					// values from xls
					keyword=controller.getCellData(currentTest, "Keyword", tsid);
					object=controller.getCellData(currentTest, "Object", tsid);
					currentTSID=controller.getCellData(currentTest, "TSID", tsid);
					stepDescription=controller.getCellData(currentTest, "Decription", tsid);
					proceedOnFail=controller.getCellData(currentTest, "ProceedOnFail", tsid);
					data_column_name=controller.getCellData(currentTest, "Data_Column_Name", tsid);
					//APPICATION_LOGS.debug(keyword);
					try{
					Method method= keywords.class.getMethod(keyword);
					String result = (String)method.invoke(method);
					// take screenshot - every keyword
					String fileName="Suite1_TC"+(tcid-1)+"_TS"+tsid+"_"+keyword+testRepeat+".jpg";
					TestUtil.takeScreenShot(CONFIG.getProperty("screenshotPath")+fileName);
					ReportUtil.addKeyword(stepDescription, keyword, result, fileName);

						if(result.startsWith("Fail")){
							testStatus=result;
						

							if(proceedOnFail.equalsIgnoreCase("N")){
								break;
							}
						
						}
					
					}catch(Throwable t){
					}
					
					
				}// keywords
				// report pass or fail
				if(testStatus == null){
					testStatus="Pass";
				}
				ReportUtil.addTestCase(currentTest, 
										startTime, 
										TestUtil.now("dd.MMMMM.yyyy hh.mm.ss aaa"),
										testStatus );
				}// test data

				
			}else{
				testStatus="Skip";
				// report skipped
				ReportUtil.addTestCase(currentTest, 
										TestUtil.now("dd.MMMMM.yyyy hh.mm.ss aaa"), 
										TestUtil.now("dd.MMMMM.yyyy hh.mm.ss aaa"),
										testStatus );
				
			}
			
			testStatus=null;
			
		}
		ReportUtil.endSuite();
	}
	
	@AfterClass
	public static void endScript(){
		
		ReportUtil.updateEndTime(TestUtil.now("dd.MMMMM.yyyy hh.mm.ss aaa"));
			
		

	}

}

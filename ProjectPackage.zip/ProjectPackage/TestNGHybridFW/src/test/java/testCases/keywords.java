package testCases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class keywords extends DriverScript{
	
	
	public static String navigate ()
	{
		if (CONFIG.getProperty("BrowserName").equals("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "C:\\Trainings\\Automation\\Addverbs\\SeleniumDriver\\geckodriver-v0.32.2-win64\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else if (CONFIG.getProperty("BrowserName").equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Trainings\\Automation\\Addverbs\\SeleniumDriver\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if (CONFIG.getProperty("BrowserName").equals("Edge"))
		{
		System.setProperty("webdriver.edge.driver", "C:\\Trainings\\Automation\\Addverbs\\SeleniumDriver\\edgedriver_win64\\msedgedriver.exe");
		driver = new EdgeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.navigate().to(CONFIG.getProperty(object));
		return "Pass";
	}
	
	public static String clickLink ()
	{
		APPLICATION_LOGS.debug("Executing Click Link functionality");
		
		try
		{
			driver.findElement(By.xpath(OR.getProperty(object))).click();
		}
		catch(Throwable t)
		{
			APPLICATION_LOGS.debug("Error in clicking on the linl - "+object +t.getMessage());
			return "Fail - Link Not Found";
		}
		
		return "Pass";
	}
	
	public static String input ()
	{
		APPLICATION_LOGS.debug("Executing input keyword");

		String data = testData.getCellData(currentTest, data_column_name, testRepeat);
		try
		{
			driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);;
		}
		catch(Throwable t)
		{
			APPLICATION_LOGS.debug("Error while wiriting in the input filed - "+object +t.getMessage());

			return "Fail - "+t.getMessage();
		}
		return "Pass";
	}
	
	public static String verifyText ()
	{
		String expected = APPTEXT.getProperty(object);
		String actual = driver.findElement(By.xpath(OR.getProperty(object))).getText();
		try
		{
			Assert.assertEquals(expected.trim(), actual.trim());
		}
		catch(Throwable t)
		{
			return "Fail - "+t.getMessage();
		}
		return "Pass";
	}


	public static String clickButton ()
	{
		APPLICATION_LOGS.debug("Executing clicking the button keyword");
		try
		{
			driver.findElement(By.xpath(OR.getProperty(object))).click();
		}
		catch(Throwable t)
		{
			APPLICATION_LOGS.debug("Error clicking on the button - "+object +t.getMessage());

			return "Fail - Link Not Found";
		}
		return "Pass";
	}
	
	public static String select ()
	{
		String data = testData.getCellData(currentTest, data_column_name, testRepeat);
		try
		{
			driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
		}
		catch(Throwable t)
		{
			return "Fail - "+t.getMessage();
		}
		return "Pass";
	}
	
	public static String clickCheckBox ()
	{
		try
		{
			driver.findElement(By.xpath(OR.getProperty(object))).click();
		}
		catch(Throwable t)
		{
			return "Fail - "+t.getMessage();
		}
		return "Pass";
	}
	
	public static String Wait() throws NumberFormatException, InterruptedException
	{
		String data = testData.getCellData(currentTest, data_column_name, testRepeat);
		Thread.sleep(Long.parseLong(data));
		
		return "Pass";
	}
	
	
}
